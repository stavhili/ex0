This is ex0 repo, you need to fork the repositery and than submit a git dir with the file ex0.c we provided in the submit system.
You need to get a mail with a "100".
If you didn't, something went wrong.
